const CACHE_NAME = "version-" +  + Math.floor(Math.random() * 100000);
const urlsToCache = [
    "offline.html",
    "index.js",
    "jquery.min.js",
    "jquery-ui.min.css",
    "jquery-ui.min.js",
    "jquery-ui.theme.min.css",
    "jquery-ui.structure.min.css",
    "website/image/ui-icons_444444_256x240.png",
    "website/image/ui-icons_555555_256x240.png",
    "website/image/ui-icons_777620_256x240.png",
    "website/image/ui-icons_777777_256x240.png",
    "website/image/ui-icons_cc0000_256x240.png",
    "website/image/ui-icons_ffffff_256x240.png"
];

// Install the service worker and open the cache and add files mentioned in array to cache
self.addEventListener('install', function(event) {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(function(cache) {
                console.log('Opened cache');
                return cache.addAll(urlsToCache);
            })
    );
});

// Listens to request from application.
self.addEventListener('fetch', function(event) {
    event.respondWith(
        caches.match(event.request)
            .then(function(response) {

                if (response) {
                    console.log(response);
                    // The requested file exists in cache so we return it from cache.
                    return response;
                }

                // The requested file is not present in cache so we send it forward to the internet
                return fetch(event.request)
                    .catch(err => {
                        console.log("err:", err)
                        return caches.match('offline.html');
                    })
            }
        )
    );
});


self.addEventListener('activate', function(event) {
    var cacheWhitelist = []; // add cache names which you do not want to delete
    cacheWhitelist.push(CACHE_NAME);
    event.waitUntil(
        caches.keys().then(function(cacheNames) {
            return Promise.all(
                cacheNames.map(function(cacheName) {
                    if (!cacheWhitelist.includes(cacheName)) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});
