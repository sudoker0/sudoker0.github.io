/*
* It has No name But its Online SHell
* Also known as: INBOSH or IN-BOSH
*
* Copyright (C) 2021 @QuanMCPC
* Released under the MIT license
*/

/**
 * A special string created for the terminal.
 */
class TerminalString extends String {
    overlayedByCursor: boolean = false;
    endOfLine: boolean = false;

    constructor({ str = "", isOverlayedByCursor = false, isEndOfLine = false }: { str?: string, isOverlayedByCursor?: boolean, isEndOfLine?: boolean }) {
        super(str);
        this.overlayedByCursor = isOverlayedByCursor;
        this.endOfLine = isEndOfLine;
    }
}

/**
 * Utility that is important for WCOS v2
 */
const util = {
    /**
     * Get the element with the given id.
     * @param elementId The name of the element
     * @returns The element with the given id
     */
    getId: (elementId: string) => {
        return document.getElementById(elementId);
    },
    /**
     * Get the text width of the given text.
     * @param canvas The canvas element to use for measuring text
     * @param text The text to measure
     * @param font The font to use
     * @returns The width of the text
     */
    getTextWidth: (canvas: HTMLCanvasElement, text: string, font: string) => {
        const context = canvas.getContext("2d");
        context.font = font;
        const metrics = context.measureText(text);
        return metrics.width;
    },
    /**
     * Get the avaliable cols and rows of the terminal.
     * @param canvas The canvas element to use for calculating
     * @param textWidth The width of the text
     * @param textHeight The height of the text
     * @param terminalMargin The margin of the terminal
     * @returns The avaliable cols and rows
     */
    calculateAvaliableColsAndRows: (canvas: HTMLCanvasElement, textWidth: number, textHeight: number, terminalMargin: number = 0) => {
        var availCol = Math.floor((canvas.width - terminalMargin * 2) / textWidth);
        var availRow = Math.floor((canvas.height - terminalMargin * 2) / textHeight);
        return { availCol, availRow };
    },
    /**
     * Draw the provided text to the terminal.
     * @param ctx The context of the canvas
     * @param screenData The data to draw
     * @param font The font to use
     * @param terminalMargin The margin of the terminal
     */
    drawTerminal: (terminal: HTMLCanvasElement, ctx: CanvasRenderingContext2D, screenData: TerminalString[][], font: string, terminalMargin: number = 0) => {
        ctx.fillStyle = "black";
        ctx.fillRect(0, 0, terminal.width, terminal.height);
        ctx.fillStyle = "white";
        ctx.font = font;
        for (let i = 0; i < screenData.length; i++) {
            for (let j = 0; j < screenData[i].length; j++) {
                ctx.fillText(screenData[i][j].valueOf(), terminalMargin + j * textWidth, terminalMargin + i * textHeight + textHeight);
            }
        }
    },
    /**
     * Draw the scroll bar
     * @param scrollBar The scroll bar to use
     * @param ctx The context of the canvas
     * @param scrollBarThumbHeight The height of the scroll bar thumb
     * @param y The y coordinate of the scroll bar thumb
     */
    drawScrollBar: (scrollBar: HTMLCanvasElement, ctx: CanvasRenderingContext2D, scrollBarThumbHeight: number, y: number) => {
        ctx.fillStyle = "rgb(64, 64, 64)";
        ctx.fillRect(0, 0, scrollBar.width, scrollBar.height);
        ctx.fillStyle = "rgb(128, 128, 128)";
        ctx.fillRect(0, Math.min(scrollBar.height - Math.round(scrollBarThumbHeight), Math.max(0, Math.round(y))), scrollBar.width, Math.round(scrollBarThumbHeight));
    },
    /**
     * Wrap the provided content to the given number of cols.
     * @param displayContent The content to wrap
     * @param maxCols The maximum number of columns
     * @returns The wrapped content
     */
    wrapTerminalContent: (displayContent: TerminalString[][], maxCols: number, maxRows: number, caretPos: { x: number, y: number }) => {
        let wrappedContent: TerminalString[][] = [];
        let currentLine: TerminalString[] = [];
        for (let i = 0; i < displayContent.length; i++) {
            for (let j = 0; j < displayContent[i].length; j++) {
                if (currentLine.length === maxCols) {
                    wrappedContent.push(currentLine);
                    currentLine = [];
                }
                currentLine.push(displayContent[i][j]);
            }
            if (currentLine.length > 0 || displayContent[i].length <= 0) {
                wrappedContent.push(currentLine);
                currentLine = [];
            }
        }
        // ? list.slice(pos - max, pos)
        if (caretPos.y - maxRows >= 0) {
            wrappedContent = wrappedContent.slice(caretPos.y - maxRows + 1, caretPos.y + 1);
        } else {
            wrappedContent = wrappedContent.slice(0, maxRows);
        }
        return wrappedContent;
    },
    /**
     * Get the position of the string.
     * @param str The string to find
     * @param arr The array to find
     * @returns The index of the string
     */
    findString: (arr: TerminalString[][]) => {
        for (let i = 0; i < arr.length; i++) {
            for (let j = 0; j < arr[i].length; j++) {
                if (arr[i][j].overlayedByCursor) {
                    return { x: j, y: i };
                }
            }
        }
        return null;
    }
}

//#region Init variables that are very important
const $terminal = util.getId("terminal") as HTMLCanvasElement;
const $terminalCtx = $terminal.getContext("2d");

const $scrollbar = util.getId("scrollbar") as HTMLCanvasElement;
const $scrollbarCtx = $scrollbar.getContext("2d");

const font = "20px Inconsolata";
const textWidth = util.getTextWidth($terminal, "#", font);
const textHeight = 20;
const terminalMargin = 5;

var terminalContent: TerminalString[][] = [[new TerminalString({isEndOfLine: true, isOverlayedByCursor: true})]];
var displayContent: TerminalString[][] = [[]];

var availSpace: { availCol: number, availRow: number };

var charThatCaretsAreOn = new TerminalString({});

var caretPos = {
    x: 0,
    y: 0
};

var prevCaretPos = {
    x: 0,
    y: 0
};

var scrollbarConfig = {
    y: 0,
    height: 0,
    leftClick: false,
}
var state = {
    commandRunning: false,
    allowInput: true,
    movingPage: false
}

var config = {
    debounceResize: true,
    debounceResizeTime: 100,
    enableScrollBar: true,
    scrollBarWidth: 20,
    scrollBar_AmountToScroll: 5
}

//#endregion
function drawCaret() {
    charThatCaretsAreOn = terminalContent[caretPos.y][caretPos.x ] || new TerminalString({});
    var coords = util.findString(displayContent);
    $terminalCtx.fillStyle = "white";
    $terminalCtx.fillRect(Math.max(1, coords.x * textWidth) + terminalMargin, coords.y * textHeight + terminalMargin + 3, textWidth, textHeight);
    $terminalCtx.fillStyle = "black";
    $terminalCtx.fillText(charThatCaretsAreOn.valueOf(), terminalMargin + coords.x * textWidth, terminalMargin + coords.y * textHeight + textHeight);
}

function insertString(str: string[], newline: boolean = false): Promise<Boolean> {
    return new Promise((resolve, _) => {
        if (newline) {
            terminalContent.push([new TerminalString({isEndOfLine: true})]);
            caretPos.y += 1;
            caretPos.x = 0;
        }
        terminalContent[caretPos.y][caretPos.x].overlayedByCursor = false;
        str.forEach((string, index) => {
            var stringArray = string.split("").map(x => new TerminalString({ str: x }));
            terminalContent[caretPos.y].splice(caretPos.x, 0, ...stringArray);
            caretPos.x += stringArray.length;

            if (index >= str.length - 1) {
                console.log("inserted");
                terminalContent[caretPos.y][caretPos.x].overlayedByCursor = true;
            } else {
                console.log("1")
                terminalContent.push([new TerminalString({isEndOfLine: true})]);
                caretPos.y += 1;
                caretPos.x = 0;
            }
        });
        displayContent = util.wrapTerminalContent(terminalContent, availSpace.availCol, availSpace.availRow, caretPos);
        util.drawTerminal($terminal, $terminalCtx, displayContent, font, terminalMargin);
        util.drawScrollBar($scrollbar, $scrollbarCtx, availSpace.availRow / terminalContent.length * $scrollbar.height, 0);
        drawCaret();
        resolve(true);
    })
}

function handleScrollbar() {
    scrollbarConfig.y = Math.min($scrollbar.height - Math.ceil(availSpace.availRow / terminalContent.length * $scrollbar.height), Math.max(0, scrollbarConfig.y));
    util.drawScrollBar($scrollbar, $scrollbarCtx, scrollbarConfig.height, scrollbarConfig.y);
    var data = util.wrapTerminalContent(terminalContent, availSpace.availCol, availSpace.availRow, { x: 0, y: Math.min(scrollbarConfig.y / $scrollbar.height * terminalContent.length + availSpace.availRow, terminalContent.length) });
    util.drawTerminal($terminal, $terminalCtx, data, font, terminalMargin);
}

function bothResizeAndLoad() {
    $terminal.width = window.innerWidth + ( config.enableScrollBar ? -config.scrollBarWidth : 0 );
    $terminal.height = window.innerHeight;

    if (config.enableScrollBar) {
        $scrollbar.width = config.scrollBarWidth;
        $scrollbar.height = window.innerHeight;
        $scrollbarCtx.fillStyle = "rgb(128, 128, 128)";
        $scrollbarCtx.fillRect(0, 0, config.scrollBarWidth, window.innerHeight);
    } else {
        $scrollbar.style.display = "none";
    }

    availSpace = util.calculateAvaliableColsAndRows($terminal, textWidth, textHeight, terminalMargin);
    displayContent = util.wrapTerminalContent(terminalContent, availSpace.availCol, availSpace.availRow, caretPos);
    util.drawTerminal($terminal, $terminalCtx, displayContent, font, terminalMargin);
    scrollbarConfig.height = availSpace.availRow / terminalContent.length * $scrollbar.height;
    scrollbarConfig.y = Math.max(0, caretPos.y - availSpace.availRow + 1) / terminalContent.length * $scrollbar.height
    handleScrollbar();
    drawCaret();
    if (config.debounceResize) { util.getId("recalibrating").style.display = "none" }
}

var resizeTimeout: number;
window.addEventListener("resize", () => {
    if (config.debounceResize) {
        util.getId("recalibrating").style.display = "flex";
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(bothResizeAndLoad, config.debounceResizeTime);
    } else {
        bothResizeAndLoad();
    }
})

window.addEventListener("load", () => {
    $terminalCtx.fillStyle = "black";
    $terminalCtx.fillRect(0, 0, $terminal.width, $terminal.height);
    bothResizeAndLoad();
})

// function oppositeOfModulo(result: number, divisor: number, limit: number) {
//     var possible: number = 0;
//     console.time("oppositeOfModulo");
//     for(let i = result; i <= limit; i = i + divisor) {
//         if (possible < limit) {
//             possible = i;
//         } else {
//             break
//         }
//     }
//     console.timeEnd("oppositeOfModulo");
//     return possible;
// }

$scrollbar.addEventListener("mousedown", (e) => {
    scrollbarConfig.leftClick = true;
})

document.addEventListener("mousemove", (e) => {
    if (e.x > document.body.clientWidth - config.scrollBarWidth * 6 && e.x < document.body.clientWidth && e.y > scrollbarConfig.y && e.y < scrollbarConfig.y + scrollbarConfig.height && scrollbarConfig.leftClick) {
        scrollbarConfig.y += e.movementY;
        handleScrollbar();
    } else {
        scrollbarConfig.leftClick = false;
    }
})

document.addEventListener("mouseup", () => {
    scrollbarConfig.leftClick = false;
    drawCaret()
})

document.addEventListener("keydown", (e) => {
    if (!state.allowInput) { return }
    prevCaretPos.x = caretPos.x;
    prevCaretPos.y = caretPos.y;
    console.log(e.key);
    switch (e.key) {

        case "PageUp":
            if (config.enableScrollBar) {
                scrollbarConfig.y -= config.scrollBar_AmountToScroll
                handleScrollbar();
                state.movingPage = true;
            }
            break;
        case "PageDown":
            if (config.enableScrollBar) {
                scrollbarConfig.y += config.scrollBar_AmountToScroll
                handleScrollbar();
                state.movingPage = true;
            }
            break;

        case "ArrowUp":
            // ! The code below is really buggy, so I have to comment it out.
            // if (terminalContent[caretPos.y].length > availSpace.availCol && caretPos.x - availSpace.availCol >= 0) {
            //     caretPos.x = caretPos.x - availSpace.availCol;
            // } else {
            //     if (terminalContent[caretPos.y].length > availSpace.availCol && caretPos.y - 1 >= 0 && caretPos.x - availSpace.availCol < 0) {
            //         caretPos.x = oppositeOfModulo(caretPos.x, availSpace.availCol, terminalContent[caretPos.y - 1].length);
            //     } else {
            //         caretPos.x = Math.min(caretPos.x, terminalContent[caretPos.y].length - 1);
            //     }
            //     caretPos.y = Math.max(0, caretPos.y - 1);
            // }
            break;

        case "ArrowDown":
            // ! The code below is really buggy, so I have to comment it out.
            // if (terminalContent[caretPos.y].length > availSpace.availCol && caretPos.x + availSpace.availCol < terminalContent[caretPos.y].length) {
            //     caretPos.x = caretPos.x + availSpace.availCol;
            // } else {
            //     caretPos.x = terminalContent[caretPos.y].length > availSpace.availCol && terminalContent.length - 1 > caretPos.y && terminalContent[caretPos.y + 1].length > availSpace.availCol
            //         ? caretPos.x % availSpace.availCol
            //         : Math.min(caretPos.x, terminalContent[caretPos.y + 1].length - 1);
            //     caretPos.y = Math.min(terminalContent.length - 1, caretPos.y + 1);
            // }
            break;

        case "ArrowLeft":
            if (caretPos.x > 0) {
                caretPos.x--;
            } else if (caretPos.y > 0) {
                caretPos.y--;
                caretPos.x = terminalContent[caretPos.y].length - 1;
            }
            break;

        case "ArrowRight":
            if (caretPos.x < terminalContent[caretPos.y].length - 1) {
                caretPos.x++;
            } else if (caretPos.y < terminalContent.length - 1) {
                caretPos.y++;
                caretPos.x = 0;
            }
            break;

        case "Home":
            caretPos.x = 0;
            break;

        case "End":
            caretPos.x = terminalContent[caretPos.y].length - 1;
            break;

        case "Enter":
            caretPos.y++;
            caretPos.x = 0;
            terminalContent.splice(caretPos.y, 0, [new TerminalString({isEndOfLine: true})]);
            // terminalContent.push([new TerminalString({isEndOfLine: true})]);
            break;

        case "Backspace":
            if (caretPos.x == 0 && caretPos.y == 0) {
                break;
            }
            if (caretPos.x <= 0) {
                caretPos.x = terminalContent[caretPos.y - 1].length - 1;
                caretPos.y--;
                var deleted = terminalContent.splice(caretPos.y + 1, 1);
                terminalContent[caretPos.y].pop();
                terminalContent[caretPos.y].push(...deleted[0]);
            } else {
                terminalContent[caretPos.y].splice(caretPos.x - 1, 1);
                caretPos.x--;
            }
            break;

        default:
            if (e.key.length == 1 && !(e.ctrlKey || e.metaKey || e.altKey)) {
                terminalContent[caretPos.y].splice(caretPos.x, 0, new TerminalString({str: e.key}));
                caretPos.x++;
            }
            break;
    }

    if (!state.movingPage) {
        scrollbarConfig.y = Math.max(0, caretPos.y - availSpace.availRow + 1) / terminalContent.length * $scrollbar.height
        scrollbarConfig.height = availSpace.availRow / terminalContent.length * $scrollbar.height;
        util.drawScrollBar($scrollbar, $scrollbarCtx, scrollbarConfig.height, scrollbarConfig.y);

        displayContent = util.wrapTerminalContent(terminalContent, availSpace.availCol, availSpace.availRow, caretPos);
        util.drawTerminal($terminal, $terminalCtx, displayContent, font, terminalMargin);

        try { terminalContent[prevCaretPos.y][prevCaretPos.x].overlayedByCursor = false } catch(e) {}
        try { terminalContent[caretPos.y][caretPos.x].overlayedByCursor = true; } catch(e) {}
        drawCaret();
    } else {
        state.movingPage = false;
    }
});