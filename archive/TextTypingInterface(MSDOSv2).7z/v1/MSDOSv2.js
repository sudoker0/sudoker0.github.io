class TerminalString extends String {
    constructor({ str = "", isOverlayedByCursor = false, isEndOfLine = false }) {
        super(str);
        this.overlayedByCursor = false;
        this.endOfLine = false;
        this.overlayedByCursor = isOverlayedByCursor;
        this.endOfLine = isEndOfLine;
    }
}
const util = {
    getId: (elementId) => {
        return document.getElementById(elementId);
    },
    getTextWidth: (canvas, text, font) => {
        const context = canvas.getContext("2d");
        context.font = font;
        const metrics = context.measureText(text);
        return metrics.width;
    },
    calculateAvaliableColsAndRows: (canvas, textWidth, textHeight, terminalMargin = 0) => {
        var availCol = Math.floor((canvas.width - terminalMargin * 2) / textWidth);
        var availRow = Math.floor((canvas.height - terminalMargin * 2) / textHeight);
        return { availCol, availRow };
    },
    drawTerminal: (ctx, screenData, font, terminalMargin = 0) => {
        ctx.fillStyle = "black";
        ctx.fillRect(0, 0, terminal.width, terminal.height);
        ctx.fillStyle = "white";
        ctx.font = font;
        for (let i = 0; i < screenData.length; i++) {
            for (let j = 0; j < screenData[i].length; j++) {
                ctx.fillText(screenData[i][j].valueOf(), terminalMargin + j * textWidth, terminalMargin + i * textHeight + textHeight);
            }
        }
    },
    wrapTerminalContent: (displayContent, maxCols) => {
        let wrappedContent = [];
        let currentLine = [];
        for (let i = 0; i < displayContent.length; i++) {
            for (let j = 0; j < displayContent[i].length; j++) {
                if (currentLine.length === maxCols) {
                    wrappedContent.push(currentLine);
                    currentLine = [];
                }
                currentLine.push(displayContent[i][j]);
            }
            if (currentLine.length > 0 || displayContent[i].length <= 0) {
                wrappedContent.push(currentLine);
                currentLine = [];
            }
        }
        return wrappedContent;
    },
    findString: (arr) => {
        for (let i = 0; i < arr.length; i++) {
            for (let j = 0; j < arr[i].length; j++) {
                if (arr[i][j].overlayedByCursor) {
                    return { x: j, y: i };
                }
            }
        }
        return null;
    }
};
const terminal = util.getId("terminal");
const ctx = terminal.getContext("2d");
const font = "20px Inconsolata";
const textWidth = util.getTextWidth(terminal, "#", font);
const textHeight = 20;
const terminalMargin = 5;
var terminalContent = [[new TerminalString({ isEndOfLine: true, isOverlayedByCursor: true })]];
var displayContent = [[]];
var availSpace;
var charThatCaretsAreOn = new TerminalString({});
var caretPos = {
    x: 0,
    y: 0
};
var prevCaretPos = {
    x: 0,
    y: 0
};
function drawCaret() {
    charThatCaretsAreOn = terminalContent[caretPos.y][caretPos.x] || new TerminalString({});
    var coords = util.findString(displayContent);
    ctx.fillStyle = "white";
    ctx.fillRect(Math.max(1, coords.x * textWidth) + terminalMargin, coords.y * textHeight + terminalMargin + 3, textWidth, textHeight);
    ctx.fillStyle = "black";
    ctx.fillText(charThatCaretsAreOn.valueOf(), terminalMargin + coords.x * textWidth, terminalMargin + coords.y * textHeight + textHeight);
}
window.addEventListener("resize", () => {
    terminal.width = window.innerWidth;
    terminal.height = window.innerHeight;
    availSpace = util.calculateAvaliableColsAndRows(terminal, textWidth, textHeight, terminalMargin);
    displayContent = util.wrapTerminalContent(terminalContent, availSpace.availCol);
    util.drawTerminal(ctx, displayContent, font, terminalMargin);
    drawCaret();
});
window.addEventListener("load", () => {
    terminal.width = window.innerWidth;
    terminal.height = window.innerHeight;
    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, terminal.width, terminal.height);
    availSpace = util.calculateAvaliableColsAndRows(terminal, textWidth, textHeight, terminalMargin);
});
document.addEventListener("keydown", (e) => {
    prevCaretPos.x = caretPos.x;
    prevCaretPos.y = caretPos.y;
    switch (e.key) {
        case "ArrowUp":
            if (terminalContent[caretPos.y].length > availSpace.availCol && caretPos.x - availSpace.availCol >= 0) {
                caretPos.x = caretPos.x - availSpace.availCol;
            }
            else {
                caretPos.y = Math.max(0, caretPos.y - 1);
                caretPos.x = Math.min(caretPos.x, terminalContent[caretPos.y].length - 1);
            }
            break;
        case "ArrowDown":
            if (terminalContent[caretPos.y].length > availSpace.availCol && caretPos.x + availSpace.availCol < terminalContent[caretPos.y].length) {
                caretPos.x = caretPos.x + availSpace.availCol;
            }
            else {
                caretPos.y = Math.min(terminalContent.length - 1, caretPos.y + 1);
                caretPos.x = Math.min(caretPos.x, terminalContent[caretPos.y].length - 1);
            }
            break;
        case "ArrowLeft":
            if (caretPos.x > 0) {
                caretPos.x--;
            }
            else if (caretPos.y > 0) {
                caretPos.y--;
                caretPos.x = terminalContent[caretPos.y].length - 1;
            }
            break;
        case "ArrowRight":
            if (caretPos.x < terminalContent[caretPos.y].length - 1) {
                caretPos.x++;
            }
            else if (caretPos.y < terminalContent.length - 1) {
                caretPos.y++;
                caretPos.x = 0;
            }
            break;
        case "Home":
            caretPos.x = 0;
            break;
        case "End":
            caretPos.x = terminalContent[caretPos.y].length - 1;
            break;
        case "Enter":
            caretPos.y++;
            caretPos.x = 0;
            terminalContent.push([new TerminalString({ isEndOfLine: true })]);
            break;
        case "Backspace":
            if (caretPos.x == 0 && caretPos.y == 0) {
                break;
            }
            if (caretPos.x <= 0) {
                caretPos.x = terminalContent[caretPos.y - 1].length - 1;
                caretPos.y--;
                terminalContent.splice(caretPos.y + 1, 1);
            }
            else {
                terminalContent[caretPos.y].splice(caretPos.x - 1, 1);
                caretPos.x--;
            }
            break;
        default:
            if (e.key.length == 1 && !(e.ctrlKey || e.metaKey || e.altKey)) {
                terminalContent[caretPos.y].splice(caretPos.x, 0, new TerminalString({ str: e.key }));
                caretPos.x++;
            }
            break;
    }
    displayContent = util.wrapTerminalContent(terminalContent, availSpace.availCol);
    util.drawTerminal(ctx, displayContent, font, terminalMargin);
    try {
        terminalContent[prevCaretPos.y][prevCaretPos.x].overlayedByCursor = false;
    }
    catch (e) { }
    try {
        terminalContent[caretPos.y][caretPos.x].overlayedByCursor = true;
    }
    catch (e) { }
    drawCaret();
});
//# sourceMappingURL=MSDOSv2.js.map