/*
 * Thanks to:
    *  - Github Copilot (for autocompleting most of the code)
    *  - Me (for the idea and writing the code)
*/

/**
 * A special string created for the terminal.
 */
class TerminalString extends String {
    overlayedByCursor: boolean = false;
    endOfLine: boolean = false;

    constructor({ str = "", isOverlayedByCursor = false, isEndOfLine = false }: { str?: string, isOverlayedByCursor?: boolean, isEndOfLine?: boolean }) {
        super(str);
        this.overlayedByCursor = isOverlayedByCursor;
        this.endOfLine = isEndOfLine;
    }
}

/**
 * Utility that is important for WCOS v2
 */

const util = {
    /**
     * Get the element with the given id.
     * @param elementId The name of the element
     * @returns The element with the given id
     */
    getId: (elementId: string) => {
        return document.getElementById(elementId);
    },
    /**
     * Get the text width of the given text.
     * @param canvas The canvas element to use for measuring text
     * @param text The text to measure
     * @param font The font to use
     * @returns The width of the text
     */
    getTextWidth: (canvas: HTMLCanvasElement, text: string, font: string) => {
        const context = canvas.getContext("2d");
        context.font = font;
        const metrics = context.measureText(text);
        return metrics.width;
    },
    /**
     * Get the avaliable cols and rows of the terminal.
     * @param canvas The canvas element to use for calculating
     * @param textWidth The width of the text
     * @param textHeight The height of the text
     * @param terminalMargin The margin of the terminal
     * @returns The avaliable cols and rows
     */
    calculateAvaliableColsAndRows: (canvas: HTMLCanvasElement, textWidth: number, textHeight: number, terminalMargin: number = 0) => {
        var availCol = Math.floor((canvas.width - terminalMargin * 2) / textWidth);
        var availRow = Math.floor((canvas.height - terminalMargin * 2) / textHeight);
        return { availCol, availRow };
    },
    /**
     * Draw the provided text to the terminal.
     * @param ctx The context of the canvas
     * @param screenData The data to draw
     * @param font The font to use
     * @param terminalMargin The margin of the terminal
     */
    drawTerminal: (ctx: CanvasRenderingContext2D, screenData: TerminalString[][], font: string, terminalMargin: number = 0) => {
        ctx.fillStyle = "black";
        ctx.fillRect(0, 0, terminal.width, terminal.height);
        ctx.fillStyle = "white";
        ctx.font = font;
        for (let i = 0; i < screenData.length; i++) {
            for (let j = 0; j < screenData[i].length; j++) {
                ctx.fillText(screenData[i][j].valueOf(), terminalMargin + j * textWidth, terminalMargin + i * textHeight + textHeight);
            }
        }
    },
    /**
     * Wrap the provided content to the given number of cols.
     * @param displayContent The content to wrap
     * @param maxCols The maximum number of columns
     * @returns The wrapped content
     */
    wrapTerminalContent: (displayContent: TerminalString[][], maxCols: number) => {
        let wrappedContent: TerminalString[][] = [];
        let currentLine: TerminalString[] = [];
        for (let i = 0; i < displayContent.length; i++) {
            for (let j = 0; j < displayContent[i].length; j++) {
                if (currentLine.length === maxCols) {
                    wrappedContent.push(currentLine);
                    currentLine = [];
                }
                currentLine.push(displayContent[i][j]);
            }
            if (currentLine.length > 0 || displayContent[i].length <= 0) {
                wrappedContent.push(currentLine);
                currentLine = [];
            }
        }
        return wrappedContent;
    },
    /**
     * Get the position of the string.
     * @param str The string to find
     * @param arr The array to find
     * @returns The index of the string
     */
    findString: (arr: TerminalString[][]) => {
        for (let i = 0; i < arr.length; i++) {
            for (let j = 0; j < arr[i].length; j++) {
                if (arr[i][j].overlayedByCursor) {
                    return { x: j, y: i };
                }
            }
        }
        return null;
    }
}

// ? Init some variables
const terminal = util.getId("terminal") as HTMLCanvasElement;
const ctx = terminal.getContext("2d");

const font = "20px Inconsolata";
const textWidth = util.getTextWidth(terminal, "#", font);
const textHeight = 20;
const terminalMargin = 5;

var terminalContent: TerminalString[][] = [[new TerminalString({isEndOfLine: true, isOverlayedByCursor: true})]];
var displayContent: TerminalString[][] = [[]];

var availSpace: { availCol: number, availRow: number };

var charThatCaretsAreOn = new TerminalString({});

var caretPos = {
    x: 0,
    y: 0
};

var prevCaretPos = {
    x: 0,
    y: 0
};

function drawCaret() {
    charThatCaretsAreOn = terminalContent[caretPos.y][caretPos.x ] || new TerminalString({});
    var coords = util.findString(displayContent);
    ctx.fillStyle = "white";
    ctx.fillRect(Math.max(1, coords.x * textWidth) + terminalMargin, coords.y * textHeight + terminalMargin + 3, textWidth, textHeight);
    ctx.fillStyle = "black";
    ctx.fillText(charThatCaretsAreOn.valueOf(), terminalMargin + coords.x * textWidth, terminalMargin + coords.y * textHeight + textHeight);
}

window.addEventListener("resize", () => {
    terminal.width = window.innerWidth;
    terminal.height = window.innerHeight;
    availSpace = util.calculateAvaliableColsAndRows(terminal, textWidth, textHeight, terminalMargin);
    displayContent = util.wrapTerminalContent(terminalContent, availSpace.availCol);
    util.drawTerminal(ctx, displayContent, font, terminalMargin);
    drawCaret();
})

window.addEventListener("load", () => {
    terminal.width = window.innerWidth;
    terminal.height = window.innerHeight;
    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, terminal.width, terminal.height);
    availSpace = util.calculateAvaliableColsAndRows(terminal, textWidth, textHeight, terminalMargin);
})

document.addEventListener("keydown", (e) => {
    prevCaretPos.x = caretPos.x;
    prevCaretPos.y = caretPos.y;
    switch (e.key) {
        case "ArrowUp":
            if (terminalContent[caretPos.y].length > availSpace.availCol && caretPos.x - availSpace.availCol >= 0) {
                caretPos.x = caretPos.x - availSpace.availCol;
            } else {
                caretPos.y = Math.max(0, caretPos.y - 1);
                caretPos.x = Math.min(caretPos.x, terminalContent[caretPos.y].length - 1);
            }
            break;

        case "ArrowDown":
            if (terminalContent[caretPos.y].length > availSpace.availCol && caretPos.x + availSpace.availCol < terminalContent[caretPos.y].length) {
                caretPos.x = caretPos.x + availSpace.availCol;
            } else {
                caretPos.y = Math.min(terminalContent.length - 1, caretPos.y + 1);
                caretPos.x = Math.min(caretPos.x, terminalContent[caretPos.y].length - 1);
            }
            break;

        case "ArrowLeft":
            if (caretPos.x > 0) {
                caretPos.x--;
            } else if (caretPos.y > 0) {
                caretPos.y--;
                caretPos.x = terminalContent[caretPos.y].length - 1;
            }
            break;

        case "ArrowRight":
            if (caretPos.x < terminalContent[caretPos.y].length - 1) {
                caretPos.x++;
            } else if (caretPos.y < terminalContent.length - 1) {
                caretPos.y++;
                caretPos.x = 0;
            }
            break;

        case "Home":
            caretPos.x = 0;
            break;

        case "End":
            caretPos.x = terminalContent[caretPos.y].length - 1;
            break;

        case "Enter":
            caretPos.y++;
            caretPos.x = 0;
            terminalContent.push([new TerminalString({isEndOfLine: true})]);
            break;

        case "Backspace":
            if (caretPos.x == 0 && caretPos.y == 0) {
                break;
            }
            if (caretPos.x <= 0) {
                caretPos.x = terminalContent[caretPos.y - 1].length - 1;
                caretPos.y--;
                terminalContent.splice(caretPos.y + 1, 1);
            } else {
                terminalContent[caretPos.y].splice(caretPos.x - 1, 1);
                caretPos.x--;
            }
            break;

        default:
            if (e.key.length == 1 && !(e.ctrlKey || e.metaKey || e.altKey)) {
                terminalContent[caretPos.y].splice(caretPos.x, 0, new TerminalString({str: e.key}));
                caretPos.x++;
            }
            break;
    }

    displayContent = util.wrapTerminalContent(terminalContent, availSpace.availCol);
    util.drawTerminal(ctx, displayContent, font, terminalMargin);
    try { terminalContent[prevCaretPos.y][prevCaretPos.x].overlayedByCursor = false } catch(e) {}
    try { terminalContent[caretPos.y][caretPos.x].overlayedByCursor = true; } catch(e) {}
    drawCaret();
});